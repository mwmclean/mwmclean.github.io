source('CIsimFunctions.R')

nsim=1000
gsize=25
n=100
J=5
trueF='hill'
nfine=200
tfine=seq(0,1,l=nfine)
bbbeta=create.bspline.basis(rangeval=c(0,1), nbasis=20,
	norder=4, breaks=NULL)
bdegt=3
ntbf=min(40,ceiling(nfine/4))
bbt=create.bspline.basis(rangeval=range(tfine), nbasis=ntbf,
	norder=bdegt+1, breaks=NULL)
snrs=c(1,2,4,8)
nsnr=length(snrs)
rmses=matrix(nr=nsim,nc=nsnr)
for(q in 1:nsim){

data=CreateData(n=n,gsize=gsize,fit='mgcv',trueF=trueF,adjustF='none',J=5,
	SNRs=snrs,lm=FALSE,sp=NULL,seed=NULL,sp0=c(1e-10,1e-10),varType='Bayes',
	xTrim=.00)
Ey=data$Ey
trainX=data$X[1:67,]
testX=data$X[68:100,]
trainXfd=smooth.basisPar(tfine,t(trainX),bbt,int2Lfd(2))$fd
testXfd=smooth.basisPar(tfine,t(testX),bbt,int2Lfd(2))$fd
sigmas=data$sigmae
rm(data)
for(j in 1:nsnr){
	trainy=Ey[1:67]+sigmas[j]*rnorm(67)
	testy=Ey[68:100]+sigmas[j]*rnorm(33)

xlist=vector('list',1)
xlist[[1]]=trainXfd
betalist=vector('list',1)
llam=seq(-10,5.5,.5) 
nlam=length(llam)
gcvs=numeric(nlam)
for(i in 1:nlam){
	lambda=10^llam[i]
	betafdpar=fdPar(bbbeta,int2Lfd(2),lambda)
	betalist[[1]]=betafdpar
	freg=fRegress(as.numeric(trainy),xlist,betalist) #no intercept
	gcvs[i]=freg$gcv
}
llam=llam[gcvs>0]
lambda=10^llam[which.min(gcvs[gcvs>0])]

betafdpar=fdPar(bbbeta,int2Lfd(2),lambda)
betalist[[1]]=betafdpar
freg=fRegress(as.numeric(trainy),xlist,betalist)

betafd2=freg$betaestlist[[1]]$fd

# compute predictions for test set
fregtestyhat=inprod(betafd2,testXfd)

fregtestres=testy-fregtestyhat
fregrmse=sqrt(mean(fregtestres^2))

rmses[q,j]=fregrmse
}
	print(paste('%done= ',100*q/nsim))
	flush.console()

}
setwd('C:\\Documents and Settings\\mwm79.ORIE\\My Documents\\Google Drive')
fname=paste('rmseFLMrpJ',J,trueF,'.RData',sep='')
save(rmses,file=fname)
colMeans(rmses)
