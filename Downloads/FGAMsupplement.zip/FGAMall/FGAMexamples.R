# Example of how to use FGAM functions

source('FGAMfunctions.R')
source('CIsimFunctions.R')

data=CreateData(n=100,fit='mgcv',trueF='hill',adjustF='fit',SNRs=c(4),lm=FALSE,
	sp=NULL,seed=NULL,sp0=c(5e-8,5e-8),varType='Bayes',xTrim=.00,
	J=500,sx=10,st=.4)
nfine=200
tfine=seq(0,1,length=nfine)
trainN=67
testN=33

data$y=data$Ey+rnorm(100)

trainy=data$Ey[1:trainN] # response values for training set
testy=data$y[-(1:trainN)] # response values for test set
trainX=data$X[1:trainN,] # predictor curve values for training set
testX=data$X[-(1:trainN),] # predictor curve values for test set

nxbf=6 #number of basis functions for x-axis
ntbf=7 #number of basis functions for t-axis
Fpdiff=2 # degree of differencing for both axis penalties
Fbdeg=3# B-spline degree for each basis
bra <- 0 # amount to enlarge x-axis B-spline range by in case curves in test set fall outside 
          # range of data in the training set
          #alternatively set PredOutOfRange=TRUE which will set outer.ok=TRUE
          # when using splines package to evaluate that basis

# fit fgam to untransformed data
fit<- fgam(y=trainy,Xlist=list(trainX),obstimes=list(tfine),
          Fbdeg=Fbdeg,Fnbfmat=c(nxbf,ntbf),Fd=Fpdiff,
          Quantiles=FALSE,fam='gaussian',gammaparm=1.4,bra=bra,bs='ps',
          presmooth=TRUE,ngrid=51,intercept=TRUE,PredOutOfRange=TRUE)
pred <- predict.fgam(fit,newXlist=list(testX),
                     newobstimes=list(tfine),type='response')

rmse=sqrt(mean( (testy-pred)^2 ));rmse

# fit fgam to quantile-transformed data
fitQ <- fgam(y=trainy,Xlist=list(trainX),obstimes=list(tfine),
                      Fbdeg=Fbdeg,Fnbfmat=c(nxbf,ntbf),Fd=Fpdiff,
                Quantiles=TRUE,fam='gaussian',gammaparm=1.4,bra=bra,bs='ps',
                    presmooth=TRUE,ngrid=51,intercept=TRUE,PredOutOfRange=TRUE)
predQ <- predict.fgam(fitQ,newXlist=list(testX),
                     newobstimes=list(tfine),type='response')

rmseQ=sqrt(mean( (testy-predQ)^2 ));rmseQ

# Contour plot of estimated surface with two transformed sample curves overlaid
#	as in Figure 3(a)

vis.fgam(fit,plot.type='contour')
vis.fgam(fit,plot.type='persp')

# Similar to Figure 4 for this dataset
nplot <- 10
tplotvals <- seq(0,1,length=nplot)
xplotvals <- seq(min(trainX),max(trainX),length=nplot)
par(ask=TRUE)
for(i in 1:nplot){
  slicesPlot(fit,nfine=201,xfixedval=xplotvals[i],tfixedval=tplotvals[i],unifscaling=FALSE)
}
  
par(ask=FALSE)
             
#############################################################################
# try using two functional predictors
#	as predictors at te same time.  Also, get confidence bands.
#############################################################################

nbf <- rbind(c(5,6),c(5,6))
Fpdiff <- c(2,2)
Fbdeg <- c(3,3)

data=CreateData(n=100,fit='mgcv',trueF='hill',adjustF='fit',SNRs=c(4),lm=FALSE,
	sp=NULL,seed=NULL,sp0=c(5e-8,5e-8),varType='Bayes',xTrim=.00,
	J=500,sx=10,st=.4)
data2=CreateData(n=100,fit='mgcv',trueF='hill',adjustF='fit',SNRs=c(4),lm=FALSE,
	sp=NULL,seed=NULL,sp0=c(5e-8,5e-8),varType='Bayes',xTrim=.00,
	J=5,sx=10,st=.4)

y=rowMeans(cbind(data$Ey,data2$Ey))+sqrt(2)*rnorm(100)
trainy=y[1:trainN]
testy=y[-(1:trainN)]
trainX1=data$X[1:trainN,] 
testX1=data$X[-(1:trainN),]
trainX2=data2$X[1:trainN,] 
testX2=data2$X[-(1:trainN),]
             
fit2 <- fgam(y=trainy,Xlist=list(trainX1,trainX2),obstimes=list(tfine,tfine),
             Fbdeg=Fbdeg,Fnbfmat=nbf,Fd=Fpdiff,
             Quantiles=FALSE,fam='gaussian',gammaparm=1.4,bra=bra,bs='ps',
             presmooth=TRUE,ngrid=51,intercept=TRUE,PredOutOfRange=TRUE)
pred2 <- predict.fgam(fit2,newXlist=list(testX1,testX2),
       newobstimes=list(tfine,tfine),type='response')

rmse2=sqrt(mean( (testy-pred2)^2 ));rmse2

par(ask=FALSE)             
par(mfrow=c(1,1))             
vis.fgam(fit2,term=1)             
vis.fgam(fit2,term=2)

#######################################################
# Include a nonparametric term for a scalar covariate
#######################################################

data=CreateData(n=100,fit='mgcv',trueF='hill',adjustF='fit',SNRs=c(4),lm=FALSE,
	sp=NULL,seed=NULL,sp0=c(5e-8,5e-8),varType='Bayes',xTrim=.00,
	J=500,sx=10,st=.4)
nfine=200
tfine=seq(0,1,length=nfine)
trainN=67
testN=33

data$y=data$Ey+rnorm(100)

trainy=data$Ey[1:trainN] # response values for training set
testy=data$y[-(1:trainN)] # response values for test set
trainX=data$X[1:trainN,] # predictor curve values for training set
testX=data$X[-(1:trainN),] # predictor curve values for test set

trainscov=trainy+rnorm(length(trainy),0,1)
testscov=testy+rnorm(length(testy),0,1)
plot(trainscov,trainy)

fit <- fgam(y=trainy,linscalpreds=NULL,npscalpreds=list(trainscov),npscalbdeg=3,
	npscalnbf=10,npscald=2,Xlist=list(trainX),obstimes=list(tfine),
	bdegmat=3,nbfmat=c(6,7),dmat=2,Quantiles=TRUE,fam='gaussian',
	gammaparm=1.4,PredOutOfRange=TRUE,bra=0)

pred <- predict.fgam(fit,newnpsplist=list(testscov),newXlist=list(testX),
       newobstimes=list(tfine),type='response')

             
# note possible error produced in predict.fgam if PredOutOfRange=FALSE and bra=0
#  and min(testscov) < min(trainscov) or max(testscov)>max(trainscov) or similarly for trainX and testX            
# NOT RUN
# fit <- fgam(y=trainy,linscalpreds=NULL,npscalpreds=list(trainscov),npscalbdeg=3,
#   npscalnbf=10,npscald=2,Xlist=list(trainX),obstimes=list(tfine),
# 	bdegmat=3,nbfmat=c(6,7),dmat=2,Quantiles=TRUE,fam='gaussian',
# 	gammaparm=1.4,PredOutOfRange=FALSE,bra=0)
# pred <- predict.fgam(fit,newnpsplist=list(testscov),newXlist=list(testX),
#        newobstimes=list(tfine),type='response')
# END NOT RUN

# if don't want to set outer.ok to TRUE in splines package,
#    the following specification enlarges the range of the x-axis basis
             
fit2 <- fgam(y=trainy,linscalpreds=NULL,npscalpreds=list(trainscov),npscalbdeg=3,
  npscalnbf=10,npscald=2,Xlist=list(trainX),obstimes=list(tfine),
  bdegmat=3,nbfmat=c(6,7),dmat=2,Quantiles=TRUE,fam='gaussian',
	gammaparm=1.4,PredOutOfRange=FALSE,bra=0.5)             

# it is still possible to get an error here depending on the generated data and how large bra is            
pred2 <- predict.fgam(fit2,newnpsplist=list(testscov),newXlist=list(testX),
       newobstimes=list(tfine),type='response')

             
# try linear effect for the scalar covariate and compare performance with the nonparametric fit

fit3 <- fgam(y=trainy,linscalpreds=trainscov,Xlist=list(trainX),obstimes=list(tfine),
	bdegmat=3,nbfmat=c(6,7),dmat=2,Quantiles=TRUE,fam='gaussian',
	gammaparm=1.4,PredOutOfRange=TRUE)

pred3 <- predict.fgam(fit3,newlsp=testscov,newXlist=list(testX),
       newobstimes=list(tfine),type='response')

rmse <- sqrt(mean( (testy-pred)^2 ));rmse
rmse2 <- sqrt(mean( (testy-pred2)^2 ));rmse2
rmse3 <- sqrt(mean( (testy-pred3)^2 ));rmse3

####################################################################
# create a binary response and fit a logistic link model FGAM
####################################################################

y=as.numeric(rnorm(100)>0)
trainy=y[1:trainN]
testy=y[-(1:trainN)]

fitL=fgam(y=trainy,Xlist=list(trainX),obstimes=list(tfine),
  bdegmat=3,nbfmat=c(6,7),dmat=2,Quantiles=TRUE,fam='binomial',m=1,
	gammaparm=1.4,PredOutOfRange=TRUE,bra=0)

pred <- predict.fgam(fitL,newlsp=testscov,newXlist=list(testX),
       newobstimes=list(tfine),type='response')

threshold=.5
predclass=as.numeric(pred>threshold)
restable=table(testy,predclass);restable
oer=1-sum(diag(restable))/sum(restable);oer
# bad performance as expected
