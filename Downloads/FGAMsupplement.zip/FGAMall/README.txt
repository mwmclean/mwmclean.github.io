This file describes the R files included in FGAM.zip.

FGAMfunctions.R � functions that must be loaded into R to fit the FGAM to work.

CIfunctions.R - additional functions used in simulation study.  Used to generate data, analyze fit, compute if points are inside convex hull defined by observed data, etc.

FGAMexamples.R   - fits several different FGAMs to simulated data and shows how to use the FGAM, predict.fgam, vis.fgam and obtain confidence bands for the fit.

FLM1simNX.R - fits FLM1 as described in Section 4   

FLM2andFAMsimNX.R - fits FLM2 and FAM as described in Section 4 

FVsimNX.R - fits the Ferraty and Vieu (2006) kernel estimator as described in Section 4.  To use this file, it is necessary to obtain their code from their website at http://www.math.univ-toulouse.fr/staph/npfda and source it into R.

FGAMsimNX.R � fits the FGAM and predicts out of sample data.  This is a stand-alone file and does not use the two scripts below.  It is a stripped-down version of FGAM.R, taking advantage of the response being Gaussian and there being only one functional predictor to speed up the simulations.

FGAMQsimNX.R � fits the FGAM and predicts out of sample data using transformed predictor functions.  This is a stand-alone file and does not use the two scripts below.  It is a stripped-down version of FGAM.R, taking advantage of the response being Gaussian and there being only one functional predictor to speed up the simulations.

simCB.R - Conducts simulation study from Section 4.2.  Repeatedly fits FGAMs to datasets generated as outlined in Section 4.2, constructs confidence bands, and checks if the true F(x,t) is contained in the confidence band.

FGAMappendix.pdf - Online Appendix for the paper.  Section A gives additional information on ensuring identifiability for the FGAM.  Section B explains in detail how to fit the FGAM using the R package mgcv.
