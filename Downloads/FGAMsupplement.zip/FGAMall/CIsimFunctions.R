library(fda)
library(mgcv)
library(lattice)

#check whether points are inside 2-d polygon defined by vertices 
#(assumes non-closed polygon, i.e head(vertices,1)!=tail(vertices,1))
insidePoly <- function(points, vertices){
    
    #angle between two vectors, enforce (-180�, 180�)
    angle <- function(v1, v2){
        ang <- (atan2(v1[2],v1[1]) - atan2(v2[2],v2[1]))
        while(ang > pi) ang <- ang - 2*pi
        while(ang < -pi) ang <- ang + 2*pi
        return(ang)
    }
    
    # idea: for a point inside the polygon, the sum of angles between 
    # x and adjacent vertices has to be 2\pi (and 0 if x is outside ?) 
    getAngleSum <- function(p, vertices){
        vertexPairs <- cbind(1:nrow(vertices), c(2:nrow(vertices),1))
        #check: p on a vertex? 
        if(paste(p, collapse=";") %in% apply(vertices, 1, paste, collapse=";")) return(2*pi)
        
        a <- apply(vertexPairs, 1, function(ind){
                    e1 <- vertices[ind[1],]- p
                    e2 <- vertices[ind[2],] - p 
                    return(angle(as.numeric(e1), as.numeric(e2)))
                })
        #if point is exactly on hull, one angle must be |180|� 
        if(any(sapply(abs(a), identical, pi))) return(2*pi)
        
        return(sum(a))
    }
    res <- apply(as.matrix(points), 1, function(p){
                #all.equal(getAngleSum(p, vertices), 2*pi)
                getAngleSum(p, as.matrix(vertices)) > pi
            })
    return(res)
}


mat.sqrt=function(A){
	d=svd(A)
	if(any(d$d<0)) stop('matrix not non-negative definite')
	d$u%*%tcrossprod(diag(d$d^.5),d$v)
}

GenSurface=function(tval=seq(0,1,l=100),type,xval=NULL,xfd=NULL,sx=5,st=.3,cons=1){
	if(length(xval)==0)
		xval=eval.fd(tval,xfd)
	if(type=='linear'){
		#return(cons*eval.fd(tval,truebetafd)*xval)
		return(cons*tval*xval)
	}else if (type=='square'){
		return( cons*(tval*xval)^2 )
	}else if (type=='linear2'){
		return(cons*2*sin(pi*tval)*xval)
	}else if(type=='sinlin'){
		return(sin(cons*tval*xval/sx))
	}else if(type=='cos'){
		return(cons*2*cos(2-xval/sx-tval/st))
	}else if(type=='sin'){
		return(cons*2*sin(2-xval/sx-tval/st))
	}else if(type=='hill'){
		return( cons*( exp(-(xval)^2/sx^2 - (tval - 
              	0.5)^2/st^2)-.5 ))
	}else if(type=='Wood'){
		 return(
           	 cons*(pi*sx * st) * (1.2 * exp(-(xval - 2)^2/sx^2 - (tval - 
             	0.3)^2/st^2) + 0.8 * exp(-(xval +2)^2/sx^2 - 
              	(tval - 0.8)^2/st^2))
	 	 )
	}
}

CreateData=function(n=100,nfine=200,SNRs=c(1e-3,1,2,4,8,1e3),trueF='linear',
	adjustF='none',seed=NULL,fit=NULL,lm=FALSE,nxbf=9,ntbf=9,Fpdiff=2,
	Fbdeg=3,gsize=25,sps=NULL,sx=5,st=.3,sp0=c(1e-9,1e-9),J=500,
	varType='sandwich',xTrim=.05){

	if(!is.null(seed))
		set.seed(seed)
	if(lm)
		if(fit=='mgcv' | fit=='SVD' | fit=='mgcvSVD')
			stop('lm fit only possible with fit= \'Con\', \'NoCon\', or \'ridge\'')
	#J=500      # 5 or 500 X rougher as J increases
	tfine=seq(0,1,length=nfine) #equally spaced observation times on [0,1]

	bbbeta=create.bspline.basis(rangeval=c(0,1), nbasis=20,
		norder=4, breaks=NULL)

	# compute predictor curves and response vector for both cases of eigenvalues
	# do this nsim times and write to file

	cosevals=sqrt(2)*cos(pi*outer(1:J,tfine))
	sinevals=sqrt(2)*sin(pi*outer(1:J,tfine))
	betavals=as.vector(crossprod((1:J)^(-4),cosevals))
	truebetafd=Data2fd(tfine,betavals,bbbeta)
	#plot(truebetafd)

	X=sapply(1:J,function(i){rnorm(n,0,2/i)})%*%cosevals+
		sapply(1:J,function(i){rnorm(n,0,2/i)})%*%sinevals

	xgrid=seq(quantile(X,xTrim),quantile(X,1-xTrim),l=gsize)
	tgrid=seq(0,1,l=gsize)

	#intFdx=apply(X,2,function(x){diff(range(x)^2)/2})*tfine #\int F(x,t)dx=.5*x^2*t
	interpF=splinefun(tfine,colSums(X))
	uF=sapply(1:gsize,function(i){
		GenSurface(tval=tgrid,type=trueF,xval=xgrid[i],sx=sx,st=st,cons=1)
		})
	intFvals=colSums(sapply(1:n,function(i){
		GenSurface(tval=tfine,type=trueF,xval=X[i,],sx=sx,st=st,cons=1)
		}))/nfine
	data=list(X=X,xgrid=xgrid,tgrid=tgrid,intFvals=intFvals)
	
	if(fit=='mgcv'){
		tmat=matrix(tfine,n,nfine,byrow=TRUE)
		L=matrix(1/nfine,n,nfine)
		data$L=L
		data$tmat=tmat
	}else{
		bbt <- create.bspline.basis(c(0, 1), nbasis=ntbf)
		bbx <- create.bspline.basis(range(X),nbasis=nxbf)
		L <- rep(1/nfine, nfine) # assumes domain [0,1]!!
		rowTensbbtevals <-  eval.basis(tfine, bbt)[,rep(1:ntbf, t=nxbf)] 

		# obtain design matrix
		Z= t(sapply(1:n,function(i){
			crossprod(L,eval.basis(X[i,],bbx)[,rep(1:nxbf,e=ntbf)]*rowTensbbtevals 
			)}))

		lam1=1e-9 #smoothing parameter
		lam2=1e-9 
		dx=2     # degree of differencing for penalty
		dt=2
		D1=diag(nxbf)
		for(i in 1:dx) D1=diff(D1)
		D2=diag(ntbf)
		for(i in 1:dt) D2=diff(D2)
		P1=kronecker(D1,diag(ntbf))
		P2=kronecker(diag(nxbf),D2)

		mat.sqrt=function(A){
			d=svd(A)
			if(any(d$d<0)) stop('matrix not non-negative definite')
			d$u%*%tcrossprod(diag(d$d^.5),d$v)
		}

		S= sp[1]*crossprod(P1)+sp[2]*crossprod(P2)
		if(fit=='ridge') S=S+1e-6*diag(nrow(S))
		sqS=mat.sqrt(S)
		augX=rbind(Z,sqS)
		
		if(fit=='Con' | fit=='SVDmgcv'){
			if(fit=='Con'){
				Cmat=matrix(1,1,nxbf)%x%diag(ntbf)
			}else{Cmat=matrix(colSums(Z),nr=1)}
			temp=qr(t(Cmat))
			Q2=qr.Q(temp,complete=TRUE)[,-(1:nrow(Cmat))]
			augX=augX%*%Q2
			data$Q2=Q2
			sqS=crossprod(Q2,sqS)%*%Q2 # crossprod(sqS,sqS)=
							   #crossprod(Q2,S)%*%Q2 b/c Q2 ortho.
		}else{
			Cmat=matrix(nr=0,nc=0)	
		}
		if(lm){
			data$augX=augX
			data$cholX=chol(crossprod(augX))
		}else{
			if(fit=='Con' | fit=='SVDmgcv'){
				qrX=qr(Z%*%Q2)
			}else{
				qrX=qr(Z)
			}
			svdRB=svd(rbind(qr.R(qrX),sqS))
			singularVals=100000
			if(fit=='SVD' | fit=='SVDmgcv')
				singularVals=which(svdRB$d < svdRB$d[1]*sqrt(.Machine$double.eps))
			data$svdRB=svdRB
			data$qrX=qrX
			data$singularVals=singularVals
		}

		tpbasisvals=array(dim=c(gsize,gsize,ntbf*nxbf))
		for(i in 1:gsize)
			tpbasisvals[i,,]=eval.basis(rep(xgrid[i],gsize),bbx)[,rep(1:nxbf,e=ntbf)]*
			eval.basis(tgrid, bbt)[,rep(1:ntbf, t=nxbf)]		

		data$tpbasisvals=tpbasisvals
		data$Z=Z
		data$Cmat=Cmat
	}
	if(adjustF=='fit'){
		if(fit=='mgcv'){
			fgam1 <- gam(intFvals~0+te(X,tmat,by=L,k=c(nxbf,ntbf),
				bs='ps',m=c(Fbdeg-1,Fpdiff)),sp=sp0)
			Ey = fgam1$fitted

			truesurfevals=matrix(nr=gsize,nc=gsize)
			 for(i in 1:gsize){
				newd <- data.frame(X = rep(xgrid[i],gsize),tmat = tgrid, L=rep(1,gsize))
			# get s.e.'s and confidence bands
		     		 lpmat <- predict(fgam1,newd,type="lpmatrix")
		      	truesurfevals[i,] <- lpmat%*%coef(fgam1) 		
			}
		}else{ sqS=mat.sqrt( sp0[1]*crossprod(P1)+sp0[2]*crossprod(P2) )
			if(lm){
				augX=rbind(Z,sqS)
				if(fit=='Con' | fit=='SVDmgcv') augX=augX%*%Q2
				augy=c(intFvals,numeric(nrow(augX)-length(intFvals)))
				lmfit=lm(augy~augX-1)
				if(fit=='Con' | fit=='SVDmgcv'){
					betahat=Q2%*%lmfit$coef
				}else{
					betahat=lmfit$coef
				}
			}else{
				if(fit=='Con' | fit=='SVDmgcv') sqS=crossprod(Q2,sqS)%*%Q2
				svdRB=svd(rbind(qr.R(qrX),sqS))
				y1=crossprod( svdRB$u[1:(ntbf*nxbf),-singularVals],
					qr.qty(qrX,intFvals)[1:(ntbf*nxbf)] )
				betahat=svdRB$v[,-singularVals]%*%diag(svdRB$d[-singularVals]^-1)%*%y1
				if(fit=='Con' | fit=='SVDmgcv') betahat=Q2%*%betahat
			}
			Ey=drop(Z%*%betahat)
			truesurfevals=sapply(1:gsize,function(i){tpbasisvals[,i,]%*%betahat})
		}
	}else if(adjustF=='none'){
		Ey=intFvals
		truesurfevals=sapply(1:gsize,function(i){
			GenSurface(tval=tgrid,type=trueF,xval=rep(xgrid[i],gsize),
			sx=sx,st=st,cons=1)})
	}else if(adjustF=='sumCon'){
		Ey=intFvals-mean(X) # E(Y|X)= int F(x,t)-n^1*sum F(X_i(t),t)
		truesurfevals=sapply(1:gsize,function(i){
			GenSurface(tval=tgrid,type=trueF,xval=rep(xgrid[i],gsize),
			sx=sx,st=st,cons=1)})-outer(rep(1,gsize),interpF(tgrid))
	}else if(adjustF=='intCon'){
		Ey=intFvals-mean(tgrid*.5*(max(X)^2-min(X)^2)) # E(Y|X)= int F(x,t)-n^1*sum F(X_i(t),t)
		truesurfevals=sapply(1:gsize,function(i){
			GenSurface(tval=tgrid,type=trueF,xval=rep(xgrid[i],gsize),
			sx=sx,st=st,cons=1)})-outer(rep(1,gsize),tgrid*.5*(max(X)^2-min(X)^2))
	}
	data$Ey=Ey
	data$truesurfevals=truesurfevals
	data$sigmae=sd(Ey)/sqrt(SNRs)	
	data$SNRs=SNRs
	data$nSNRs=length(SNRs)
	data$fit=fit
	data$trueF=trueF
	data$adjustF=adjustF
	data$lm=lm
	data$n=n
	data$gsize=gsize
	data$nxbf=nxbf
	data$ntbf=ntbf
	data$Fpdiff=Fpdiff
	data$Fbdeg=Fbdeg
	data$sps=sps
	if(adjustF=='fit'){
		data$sp0=sp0
		data$uF=uF
	}
	data$vt=ifelse(varType=='sandwich','SW','Bayes')	
	data$xTrim=xTrim
	return(data)
}

RunSim=function(data,nsim=500,dir='Z:/',save=TRUE,clevel=.95){
	#attach(data)
	for(k in 1:data$nSNRs){
		in951=array(0,dim=c(nsim,data$gsize,data$gsize))
		Fs1=in951
		stds1=Fs1
		edfs1=numeric(nsim)
		sigmas1=numeric(nsim)
		biases1=matrix(0,nr=nsim,nc=data$n)
		bTime=Sys.time()
	
		for(j in 1:nsim){
			rn=rnorm(data$n)
			y=data$Ey+rn*data$sigmae[k]
	
			fitres=FitEval(y=y,data=data,fit=data$fit,lm=data$lm,clevel=clevel)	
			in951[j,,]=fitres$in95
			Fs1[j,,]=fitres$Fs
			stds1[j,,]=fitres$stds
			edfs1[j]=fitres$edf
			sigmas1[j]=fitres$sigma
			biases1[j,]=fitres$bias
		}
		eTime=Sys.time()-bTime;print(eTime)
		if(save){
			setwd(dir)
			Ey=data$Ey
			truesurfevals=data$truesurfevals
			xgrid=data$xgrid
			intFvals=data$intFvals
			sp0=data$sp0	
			uF=data$uF
			fname=paste('NewSNR',data$SNRs[k],'FGAM',data$vt,data$n,data$trueF,data$fit,100*data$xTrim,'.RData',sep='')
			if(is.null(sp0)){
				save(in951,Fs1,stds1,edfs1,Ey,truesurfevals,biases1,sigmas1,
					xgrid,intFvals,file=fname)
			}else{
				save(in951,Fs1,stds1,edfs1,Ey,truesurfevals,biases1,sigmas1,
					xgrid,intFvals,sp0,uF,file=fname)

			}
		}
		#else{
			
		#}

		print(paste('%done= ',100*k/data$nSNRs))
		flush.console()
	}#end loop over signal to noise ratios
		#detach(data)
		return(list(in951=in951,Fs1=Fs1,stds1=stds1,edfs1=edfs1,uF=data$uF,
			Ey=data$Ey,truesurfevals=data$truesurfevals,intFvals=data$intFvals,
			biases1=biases1,sigmas1=sigmas1,xgrid=data$xgrid))
}# end RunSim function

FitEval=function(y,data,fit,lm,clevel=.95){
	attach(data)
	res=list()
	zval=qnorm(1-(1-clevel)/2)
 	Fs=matrix(nr=gsize,nc=gsize)
	stds=matrix(nr=gsize,nc=gsize)
	in95=matrix(nr=gsize,nc=gsize)
	if(fit=='mgcv'){

		if(is.null(data$sps)) sps=NULL
		#browser()
		fgam1 <- gam(y~0+te(X,tmat,by=L,k=c(nxbf,ntbf),bs='ps',
			m=c(Fbdeg-1,Fpdiff)),sp=sps)
		res$edf=sum(fgam1$edf)

		mm=model.matrix(fgam1)
		hat=mm%*%tcrossprod(vcov(fgam1,disp=1),mm)
		res$bias=(diag(n)-hat)%*%Ey
		res$sigma=sqrt(fgam1$sig)

	    for(i in 1:gsize){
		newd <- data.frame(X = rep(xgrid[i],gsize),tmat = tgrid, L=rep(1,gsize))
		# get s.e.'s and confidence bands
	      lpmat <- predict(fgam1,newd,type="lpmatrix")
	      Fest <- lpmat%*%coef(fgam1) 
      	if(vt=='SW'){
			Festsd <- rowSums(lpmat%*%fgam1$Ve*lpmat)^.5
		}else{
			Festsd <- rowSums(lpmat%*%fgam1$Vp*lpmat)^.5		
		}
	  	Fs[i,]<-Fest
 		stds[i,]<-Festsd
	      # check if true surface in confidence bands
  
      	in95[i,]= truesurfevals[i,] > Fest-zval*Festsd & 
				truesurfevals[i,] < Fest+zval*Festsd
	    }# end for
	}else if(lm){

		augy=c(y,numeric(nrow(augX)-length(y)))
		lmfit=lm(augy~augX-1)
		if(fit=='Con' | fit=='SVDmgcv') lmfit$coef=Q2%*%lmfit$coef
		res$edf=sum(hatvalues(lmfit)[1:n])
		sig2estlm=sum(lmfit$res^2)/(n-ncol(augX))
		sig2estgam=sum(lmfit$res^2)/(n-res$edf)
		srQ=sig2estgam/sig2estlm


		hat=(augX%*%tcrossprod(chol2inv(cholX),augX))[1:n,1:n]
		res$bias=(diag(n)-hat)%*%Ey		 #    bayesian cov est.
		res$sigma=sqrt(sig2estgam)

  	       for(i in 1:gsize){
			Fest=tpbasisvals[i,,]%*%lmfit$coef
			if(fit=='Con'){
				Festsd=sqrt( srQ*diag( tpbasisvals[i,,]%*%Q2%*%tcrossprod(
					tcrossprod(vcov(lmfit),Q2),tpbasisvals[i,,]) ) )
			}else{
				Festsd=sqrt( srQ*diag( tpbasisvals[i,,]%*%tcrossprod(
					vcov(lmfit),tpbasisvals[i,,]) ) )
			}
  			Fs[i,]<-Fest
 			stds[i,]<-Festsd
  
     			 in95[i,]= truesurfevals[i,] > Fest-zval*Festsd & 
				truesurfevals[i,] < Fest+zval*Festsd
    		} #end for

	}else{
		y1=crossprod( svdRB$u[1:(ntbf*nxbf-nrow(Cmat)),-singularVals],
			qr.qty(qrX,y)[1:(ntbf*nxbf-nrow(Cmat))] )
		betahat=svdRB$v[,-singularVals]%*%diag(svdRB$d[-singularVals]^-1)%*%y1
		if(fit=='Con' | fit=='SVDmgcv') betahat=Q2%*%betahat
		res$edf=sum(diag(tcrossprod(svdRB$u[1:(ntbf*nxbf-nrow(Cmat)),-singularVals])));#edf
		#ntbf*nxbf-length(singularVals)-qr(S)$rank
		yhat=Z%*%betahat
		hat=tcrossprod(qr.Q(qrX)%*%svdRB$u[1:(ntbf*nxbf-nrow(Cmat)),-singularVals])
		res$bias=(diag(n)-hat)%*%Ey
		res$sigma=sqrt(sum( (y-yhat)^2 )/(n-res$edf))

		Vbeta=res$sigma*svdRB$v[,-singularVals]%*%tcrossprod(diag(svdRB$d[-singularVals]^-2),
			svdRB$v[,-singularVals])
		Zsvd=svdRB$u[1:(ntbf*nxbf-nrow(Cmat)),-singularVals]%*%tcrossprod(diag(svdRB$d[-singularVals]),svdRB$v[,-singularVals])
		Vsand=1/res$sigma*Vbeta%*%crossprod(Zsvd)%*%Vbeta
		if(fit=='Con' | fit=='SVDmgcv') Vsand=Q2%*%tcrossprod(Vsand,Q2)
	    # get s.e.'s and confidence bands
		for(i in 1:gsize){
	   	   Fs[i,]=tpbasisvals[i,,]%*%betahat
		   stds[i,]=rowSums(tpbasisvals[i,,]%*%Vsand*tpbasisvals[i,,])^.5
  
      	   in95[i,]= truesurfevals[i,] > Fs[i,]-zval*stds[i,] & 
			truesurfevals[i,] < Fs[i,]+zval*stds[i,]
	    }#end for

	} #end if for fit type
	res$Fs=Fs
	res$stds=stds
	res$in95=in95
	detach(data)
	return(res)
}# end FitEval function

PlotRes=function(test,contour=FALSE,colour=TRUE){
aveseF=colMeans(test$stds1)
sdF=apply(test$Fs1,c(2,3),sd)
aveF=colMeans(test$Fs1)
trueF=test$truesurfevals
ACP=colMeans(test$in951)
covAveF=vapply(1:nrow(test$in9),function(i){
	aveF < test$Fs1[i,,]+qnorm(.975)*test$stds1[i,,] &
	aveF > test$Fs1[i,,]-qnorm(.975)*test$stds1[i,,]
	},FUN.VALUE=matrix(nr=25,nc=25))
covAveF=rowMeans(covAveF,dim=2)
cbMiss=vapply(1:nrow(test$in95),function(i){
	(trueF-test$Fs1[i,,]+qnorm(.975)*test$stds1[i,,])*(trueF>test$Fs1[i,,]+qnorm(.975)*test$stds1[i,,])+
	(test$Fs1[i,,]+qnorm(.975)*test$stds1[i,,]-trueF)*(trueF<test$Fs1[i,,]-qnorm(.975)*test$stds1[i,,])
	},FUN.VALUE=matrix(0,nr=25,nc=25))
cbMiss=rowMeans(cbMiss,dim=2)
#dim(cbMiss)
#temp=apply(covAveF,3,mean)
#dim(covAveF)
temp=expand.grid(test$xgrid,seq(0,1,l=length(test$xgrid)))
x=temp$Var1
y=temp$Var2

if(contour){
a=contourplot(ACP~x*y,xlab='x',ylab='t',main=paste('a) Mean Coverage',sep=''))
b=contourplot((aveF-trueF)/sdF~x*y,xlab='x',ylab='t',main=paste('b) (Mean Estimated F - True F)/M.C.seF',sep=''))
c=contourplot(aveseF/sdF~x*y,xlab='x',ylab='t',main=paste('c) Mean std. err. est. F / M.C. std. err. est. F'))
d=contourplot(covAveF~x*y,xlab='x',ylab='t',main=paste('d) Mean Coverage of Mean Est. F'))
e=contourplot(cbMiss~x*y,xlab='x',ylab='t',main=paste('e) Average Under/Over-Cov. Amount'))
}else{
a=levelplot(ACP~x*y,xlab='x',ylab='t',main=paste('a) Mean Coverage',sep=''))
b=levelplot((aveF-trueF)/sdF~x*y,xlab='x',ylab='t',main=paste('b) (Mean Estimated F - True F)/M.C.seF',sep=''))
c=levelplot(aveseF/sdF~x*y,xlab='x',ylab='t',main=paste('c) Mean std. err. est. F / M.C. std. err. est. F'))
d=levelplot(covAveF~x*y,xlab='x',ylab='t',main=paste('d) Mean Coverage of Mean Est. F'))
e=levelplot(cbMiss~x*y,xlab='x',ylab='t',main=paste('e) Average Under/Over-Cov. Amount'))
}
sty <- list()
sty$axis.line$col <- NA
sty$strip.border$col <- NA
sty$strip.background$col <- NA
f=xyplot(0~0*0, 
       panel = function(...) { 
	panel.text(2, 9, paste('ACP=',round(mean(test$in95,na.rm=TRUE),4)))
	panel.text(2, 8, paste('# NA\'s=',sum(is.na(test$in95))))
	panel.text(3, 7, paste('mean | E(Y|X)-\\int F |=',round(mean(abs(test$Ey-test$intF)),4)))
	panel.text(3, 6, paste('mean effective d.f.=',round(mean(test$edfs,na.rm=TRUE),4)))
	panel.text(4, 5, paste('mean (Identity-Hmatrix)E(Y|X)=',round(mean(test$biases,na.rm=TRUE),4)))
         panel.text(2, 4, paste('sigma=',round(sd(test$Ey)/sqrt(test$snr),4)))
         panel.text(3, 3, paste('mean est. sigma=',round(mean(test$sigmas1),4)))
         panel.xyplot(...) 
       },xlim=c(0,10),ylim=c(0,10),ylab='',xlab='',par.settings=sty,
	scales = list(alternating = c(0,0), tck = c(0,0))) 

if(!colour) trellis.device(color = FALSE)
print(a,position=c(.1,.1,1,1),split=c(1,1,3,2),more=TRUE)
print(c,position=c(.1,.1,1,1),split=c(1,2,3,2),more=TRUE)
print(b,position=c(.1,.1,1,1),split=c(2,1,3,2),more=TRUE)
print(d,position=c(.1,.1,1,1),split=c(2,2,3,2),more=TRUE)
print(e,position=c(.1,.1,1,1),split=c(3,1,3,2),more=TRUE)
print(f,position=c(.1,.1,1,1),split=c(3,2,3,2),more=FALSE)

}

