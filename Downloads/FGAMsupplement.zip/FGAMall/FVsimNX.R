# fit Ferraty and (2006) functional kernel regression model to simulated data
# must obtain code from http://www.math.univ-toulouse.fr/staph/npfda 

source('CIsimFunctions.R')

nsim=1000
gsize=25
n=100
J=5
trueF='linear'
nknot=40
snrs=c(1,2,4,8)
nsnr=length(snrs)
rmsesNP=matrix(nr=nsim,nc=nsnr)
for(q in 1:nsim){

data=CreateData(n=n,gsize=gsize,fit='mgcv',trueF=trueF,adjustF='none',J=J,
	SNRs=snrs,lm=FALSE,sp=NULL,seed=NULL,sp0=c(1e-10,1e-10),varType='Bayes',
	xTrim=.00)
Ey=data$Ey
trainX=data$X[1:67,]
testX=data$X[68:100,]
sigmas=data$sigmae
rm(data)
for(j in 1:nsnr){
	trainy=Ey[1:67]+sigmas[j]*rnorm(67)
	testy=Ey[68:100]+sigmas[j]*rnorm(33)

	fit=funopare.knn.lcv(trainy, trainX, testX,q=0,nknot=nknot,
		range.grid=c(0,1),kind.of.kernel = "quadratic", semimetric = "deriv")

	yhattestnpfda=fit$Pred
	rmsesNP[q,j]=sqrt(mean((testy-yhattestnpfda)^2))
}
print(paste(100*q/nsim,'% complete',sep=''))
flush.console()
}

fname=paste('rmseFVJ',J,trueF,'.RData',sep='')
save(rmsesNP,file=fname)
colMeans(rmsesNP)
