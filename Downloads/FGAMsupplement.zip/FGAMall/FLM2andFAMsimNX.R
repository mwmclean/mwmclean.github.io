source('CIsimFunctions.R')

nsim=1000
gsize=25
n=100
J=500
trueF='linear'
nfine=200
tfine=seq(0,1,l=nfine)
snrs=c(1,2,4,8)
nsnr=length(snrs)

	bdegt=3
	ntbf=min(40,ceiling(nfine/4))
# basis to use for pre-smoothing the functional predictors
	bbt=create.bspline.basis(rangeval=range(tfine), nbasis=ntbf,
		norder=bdegt+1, breaks=NULL)



temp=(1:J)^-2
numpcs=which( cumsum(temp)/sum(temp) >.9 )[1]
k=11#=floor(67/numpcs) when J=500

pcnames=numeric(numpcs)
model='trainy~'
for(i in 1:numpcs){
  pcnames[i]=paste('pc',i,sep='')
    model=paste(model,'s(pc',i,',k=',k,')+',sep='')
}
model=substr(model,1,nchar(model)-1)
#NO INTERCEPT
model=paste(model,'-1',sep='')

rmsesFLM=matrix(nr=nsim,nc=nsnr)
rmsesFAM=matrix(nr=nsim,nc=nsnr)
for(q in 1:nsim){

data=CreateData(n=n,gsize=gsize,fit='mgcv',trueF=trueF,adjustF='none',J=J,
	SNRs=snrs,lm=FALSE,sp=NULL,seed=NULL,sp0=c(1e-10,1e-10),varType='Bayes',
	xTrim=.00)
Ey=data$Ey
trainX=t(data$X[1:67,])
testX=t(data$X[68:100,])
sigmas=data$sigmae
rm(data)

# pre-smooth data for use with pca.fd
trainXfd=smooth.basisPar(tfine,trainX,bbt,int2Lfd(2))$fd
testXfd=smooth.basisPar(tfine,testX,bbt,int2Lfd(2))$fd


# perform fPCA
lambda=10^-8 # smoothing parameter values for pca.fd
tempfdpar=fdPar(trainXfd$basis,int2Lfd(2),lambda) #principal component functions 
pcafd=pca.fd(trainXfd,numpcs,tempfdpar)

for(j in 1:nsnr){
	trainy=Ey[1:67]+sigmas[j]*rnorm(67)
	testy=Ey[68:100]+sigmas[j]*rnorm(33)




# fit linear model with pc scores as predictors

pcaout=lm(trainy~0+pcafd$sc)
pcacoef=pcaout$coef

# compute estimated coefficient function
# NO INTERCEPT
betafd=0*pcafd$har[1]
for(i in 1:numpcs){betafd=betafd+pcafd$har[i]*pcacoef[i]}

# mise[q]=inprod(betafd-truebetafd,betafd-truebetafd)
# compute predictions for test data
yhatfregpctest=drop(inprod(betafd,testXfd))
fregpcres=testy-yhatfregpctest
fregrmse=sqrt(mean(fregpcres^2))

rmsesFLM[q,j]=fregrmse

# fit Y+M FAM model using fda's fPCA() + mgcv's gam()
pcscores <- as.data.frame(pcafd$sc)
names(pcscores) <- pcnames
famfit <- try(gam(as.formula(model),data=pcscores))
# in very rare cases for the well-spaced eigenvalue, alpha=1.1 cases gam fails to converge. bam does not
if(class(famfit)[1]!='gam'){ 
  famfit <- bam(as.formula(model),data=pcscores)
}

# now get out of sample predictions
yhatFAM=numeric(ncol(testX))
for(i in 1:ncol(testX)){
  Xfdi=testXfd[i]
  # get pc scores, c, for ith curve using c_{ij}=\int\theta_j(t)(x_i(t)-\bar(x)(t))dt
  pcsi <- numeric(numpcs)
	for(l in 1:numpcs){
	  pcsi[l] <- inprod(pcafd$harm[l],Xfdi-pcafd$meanfd)
	}
	names(pcsi) <- pcnames
	newdat=as.list(pcsi)

	yhatFAM[i] <- predict(famfit,newdata=newdat)
}

rmsesFAM[q,j]=sqrt(mean((testy-yhatFAM)^2))

} #end loop of SNRs
print(paste(100*q/nsim,'% complete',sep=''))
flush.console()
}
setwd('Z:/')
fname=paste('rmseFAMJ',J,trueF,'.RData',sep='')
save(rmsesFLM,rmsesFAM,file=fname)

colMeans(rmsesFLM)
colMeans(rmsesFAM)
mean(rmsesFRpc2)
mean(rmsesFAMpc1)
mean(rmsesFAMpc2)