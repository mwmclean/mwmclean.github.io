# new version of FGAM code using mgcv

# bra= adjustment to definitions of basis ranges to account for possible
#   test data outside range of training data.  0 corresponds to no correction
#   Should be small positive number.  Specifying bra too large will result
#   in a warning from gam() about having no information for some basis coefficients

library(fda)
library(mgcv)
library(lattice)

fgam <- function(y,linscalpreds=NULL,npscalpreds=NULL,npscalbdeg=NULL,
  npscalnbf=NULL,npscald=NULL,Xlist,obstimes,Fbdeg=NULL,Fnbfmat=NULL,Fd=NULL,
  Quantiles=FALSE,fam='gaussian',gammaparm=1,bra=NULL,m=NULL,intercept=TRUE,
	sp=NULL,lbsps=NULL,bs='ps',presmooth=TRUE,ngrid=101,ubsps=NULL,
	PredOutOfRange=FALSE,big=FALSE,...){

	N=length(y)
	numlp=ifelse(is.matrix(linscalpreds),ncol(linscalpreds),ifelse(is.null(linscalpreds),0,1))
	numap=length(npscalpreds)#ifelse(is.matrix(npscalpreds),ncol(npscalpreds),ifelse(is.null(npscalpreds),0,1))
	numfp=length(Xlist)
  
  if(bs=='ps' & length(bra)!=numfp){
    bra=numeric(numfp)
    if(!Quantiles){
      bra  <- bra+.01 
    }
  }

	if(fam=='binomial'){
		if(is.null(m)){
			stop('must specify m=#of trials when using binomial family')
		}else{
			temp=y
			y=matrix(nrow=N,ncol=2)
			y[,1]=temp
			y[,2]=m-y[,1]
		}
	}
  
  # stop unnecessary, known warnings from later gam() call
  #   related to using NULL instead of NA to specify using default parameters
  stopWarnings <- function(w) if( any( grepl( "m wrong length", w) ) | 
                        any( grepl( "is.na()", w) ) ){
    invokeRestart( "muffleWarning" )}

	model <- ifelse(intercept,"y~","y~0+")
  
	if(numlp>0)
	#for(i in 1:numlp){
		model=paste(model,"linscalpreds+",sep='')
	#}

   ranges <- list()

	if(numap>0){
		if(length(npscalnbf)!=numap | !is.numeric(npscalnbf) | !all(npscalnbf>0))
			stop('Non-linear scalar predictors specified incorrectly')		

		if(numap==1) npscalpreds=matrix(npscalpreds,ncol=1)
	
		for(j in 1:numap){
      assign(paste('z',j,sep=''),npscalpreds[[j]])
      ranges[[paste('z',j,sep='')]] <- range(npscalpreds[[j]])+
        c(-bra[j]*abs(min(npscalpreds[[j]])),bra[j]*abs(max(npscalpreds[[j]])))
        if(bs=='cr'){
          model=paste(model,"s(z",j,",k=npscalnbf[",j,"],bs=\"cr\")+",sep='')
        }else if(bs=='ps'){
			    model=paste(model,"s(z",j,",k=npscalnbf[",j,"]",
				  ",m=c(npscalbdeg[",j,"]-1,npscald[",j,"]),bs=\"ps\")+",sep='')
        }else{stop('Invalid basis specified')}
		}
	}
 
	if(numfp>0){
    if(numfp==1 & !is.null(Fnbfmat)) Fnbfmat <- matrix(Fnbfmat,nrow=1)
		for(j in 1:numfp){ 
        		nt=length(obstimes[[j]])
            ngrid=ifelse(presmooth,ngrid,nt)
            
  
  		ranges[[paste('tmat',j,sep='')]] <- range(obstimes[[j]])
      if(bs=='ps'){
  		if(Quantiles){
				ranges[[paste('X',j,sep='')]] <- c(0,1)
			}else{ # get ranges before smoothing to avoid problems with later prediction
        #assign(paste('X',j,sep=''),Xlist[[j]])
        ranges[[paste('X',j,sep='')]] <- range(Xlist[[j]])+
          c(-bra[j]*abs(min(Xlist[[j]])),bra[j]*abs(max(Xlist[[j]])))
			}      
      }
      if(presmooth){

      	  # basis for x or quantile axis for jth functional covariate
	    	  # note difference in range depending on if transform is used
# 	      	bbx=create.bspline.basis(rangeval=ifelse(c(Quantiles[j],Quantiles[j]),
# 			      c(0,1),range(Xlist[[j]])+c(-bra[j]*abs(min(Xlist[[j]])),
# 			      bra[j]*abs(max(Xlist[[j]])))),
# 			      nbasis=ifelse(is.null(Fnbfmat[j,]),5,Fnbfmat[j,1]),
#               norder=ifelse(is.null(Fbdeg[j]),4,Fbdeg[j]+1), breaks=NULL) 
		      bbt=create.bspline.basis(rangeval=range(obstimes[[j]]), 
			      #nbasis=ifelse(is.null(Fnbfmat[j,]),min(40,
            #                                  ceiling(length(obstimes[[j]])/4)),
            #              Fnbfmat[j,2]),
            nbasis=ceiling(length(obstimes[[j]])/4),                                   
              norder=ifelse(is.null(Fbdeg[j]),4,Fbdeg[j]+1), breaks=NULL)

		      # pre-smooth functional predictor
          temp <- smooth.basisPar(obstimes[[j]],t(Xlist[[j]]),bbt,int2Lfd(2)) 
		      Xfd <- temp$fd
          assign(paste('y2cmap',j,sep=''),temp$y2cMap)
          assign(paste('basis',j,sep=''),bbt)
  	      obstimes[[j]] <- seq(min(obstimes[[j]]),max(obstimes[[j]]),length=ngrid)
          Xlist[[j]] <- t(eval.fd(obstimes[[j]],Xfd))

        # need to check that smoothing didn't enlarge range of data
#           if(max(Xlist[[j]])>ranges[[length(ranges)]][2] | 
#               min(Xlist[[j]])<ranges[[length(ranges)]][1]){
#                  ranges[[length(ranges)]] <- range(Xlist[[j]])+
#                    c(-bra[j]*abs(min(Xlist[[j]])),bra[j]*abs(max(Xlist[[j]])))
#           }
          if(!Quantiles & bs=='ps'){
          if(max(Xlist[[j]])>ranges[[length(ranges)]][2]){
            ranges[[length(ranges)]][2] <- max(Xlist[[j]])+bra[j]*abs(max(Xlist[[j]]))
          } 
          if(min(Xlist[[j]])<ranges[[length(ranges)]][1]){
            ranges[[length(ranges)]][1] <- min(Xlist[[j]])-bra[j]*abs(min(Xlist[[j]]))
          }
          }
        }
              
      assign(paste('tmat',j,sep=''), matrix(obstimes[[j]],N,ngrid,byrow=TRUE))
      if(Quantiles){
          ranges[[paste('X',j,sep='')]] <- c(0,1)
          assign(paste('X',j,sep=''), apply(Xlist[[j]], 2, function(x){
  				(rank(x)-1)/(length(x)-1)} ))
          # need to keep ecdf's for prediction later
            assign(paste('ecdf',j,sep=''), apply(Xlist[[j]], 2, ecdf))      
      }else{assign(paste('X',j,sep=''),Xlist[[j]])}

        #browser()
      Li <- diff(obstimes[[j]])[1]
			#Li <- diff(range(obstimes[[j]]))/(2*ngrid) * c(1, rep(2, ngrid-2), 1)
	assign(paste('L',j,sep=''), matrix(Li, nr=N, nc=ngrid, byrow=TRUE))
      if(bs=='cr'){    
           model=paste(model,"te(X",j,",tmat",j,",by=L",j,",bs=\'cr\',",
   			"k=Fnbfmat[",j,",])+",sep='')
      }else if (bs=='ps'){
			model=paste(model,"te(X",j,",tmat",j,",by=L",j,",bs=\'ps\',",
				"k=Fnbfmat[",j,",],m=c(Fbdeg[",j,"]-1,Fd[",j,"]))+",sep='')
      }else{stop('invalid basis type specified')}
		}
	}
	model=substr(model,1,nchar(model)-1)   # remove the extra '+' at the end 
  
  if(bs=='cr') ranges=NULL # bases ranges only specified for P-splines
                    # this can be necessary if test data falls outside ranges
  #browser()
  if(!big){	
	res=withCallingHandlers(gam(as.formula(model),family=fam,min.sp=lbsps,
                              gamma=gammaparm,knots=ranges,sp=sp,
                                ...),warning=stopWarnings)
  }else{
	res=withCallingHandlers(bam(as.formula(model),family=fam,min.sp=lbsps,
                              gamma=gammaparm,knots=ranges,sp=sp,
                                ...),warning=stopWarnings)
  }
  res$gamcall <- model
  res$PredOutOfRange <- PredOutOfRange
  if(bs=='ps') res$ranges <- ranges
  if(fam=='binomial')res$m <- m
  if(Quantiles){
    res$ecdflist <- list() 
    for(j in 1:numfp){
      res$ecdflist[[j]] <- get(paste('ecdf',j,sep=''))
    }
  }
  if(presmooth){
    res$basislist <- list()
    res$y2cmaplist <- list()
    for(j in 1:numfp){
      res$basislist[[j]] <- get(paste('basis',j,sep=''))
      res$y2cmaplist[[j]] <- get(paste('y2cmap',j,sep=''))
    }
    res$ngrid <- ngrid
  }
#   res$L=L1
#   res$tmat1 <- tmat1
#   res$X1 <- X1
#   res$Li <- Li
  class(res) <- c('fgam','gam','glm','lm')
	return(res)
}



# try multiple functional predictors
# type='link' not implemented
# only specify values for desired F surface (the one corresponding to term). if surface predictions wanted
# if prediction of surface values is desired, newXlist and newobstimes should be both be lists
# containing a single vector
predict.fgam <- function(fit,newlsp=NULL,newnpsplist=NULL,newXlist,newobstimes,
                          type=c('response','surface','link'),term=NULL){
  N=ifelse(is.matrix(newXlist[[1]]),nrow(newXlist[[1]]),1)          
  #nt=ifelse(N==1,length(newobstimes[[1]]),ncol(newobstimes[[1]]))
  numfp <- length(newXlist)
  m <- fit$m    # needed to do predictions for binomial case
  if(is.null(m))m=1 # predict.gam doesn't seem to return predicted
                                #  responses, only probabilities for binomial case
  # 
  if(fit$PredOutOfRange){
    trace(splines::spline.des, at=2, quote({
                        outer.ok <- TRUE
                    }),print=FALSE)
     on.exit(untrace(splines::spline.des))
  }

  type=match.arg(type,c('response','surface','link'))
  if(type=='surface' | type=='link'){
  
    # NOTE: if type='surface', code assumes length(newXlist)=length(newobstimes)=1
      # i.e. only values for term desired for plotting are supplied
    
    if(is.null(term)){
      stop('Specify the functional predictor whose estimated surface is desired. Set argument term=1,2,3,etc.')
    }
    nt <- ifelse(N==1,length(newobstimes[[1]]),ncol(newobstimes[[1]]))
  if( (min(newXlist[[1]])<0 | max(newXlist[[1]])>1) & !is.null(fit$ecdflist) ){
		warning('FGAM fit with quantiles.  Values for prediction should be in (0,1).  Using equally spaced grid instead')
		newXlist[[1]]=seq(0,1,l=nt) #matrix(seq(0,1,l=nt),
			#nrow=N,ncol=nt,byrow=TRUE)
	}
	#browser()

    newdata <- list(as.vector(newXlist[[1]]),as.vector(newobstimes[[1]]),
                                    1+numeric(N*nt)) #rep(1,nt)

    names(newdata) <- c(paste('X',term,sep=''),paste('tmat',term,sep=''),
                        paste('L',term,sep=''))
    #browser()
    term=paste('te(X',term,',tmat',term,'):L',term,sep='')
    return(
      matrix(predict(fit,newdata=newdata,type='terms',terms=term),nr=N,nc=nt)
      )
  }else if(type=='response'){   
    newdata <- list()
    
    for(j in 1:numfp){
    
        nt <- length(newobstimes[[j]])
      # if presmoothing done during fitting, presmooth new data using original estimates 
      if(!is.null(fit$basislist)){
        nt <- fit$ngrid
        bbt <- fit$basislist[[j]]
        if(N==1){
         # browser()
          Xfd <- fd(fit$y2cmaplist[[j]]%*%newXlist[[j]],bbt)
        }else{
          Xfd <- fd(tcrossprod(fit$y2cmaplist[[j]],newXlist[[j]]),bbt)
        }
        tfine <- seq(bbt$rangeval[1],bbt$rangeval[2],l=nt)
        newXlist[[j]] <- t(eval.fd(tfine,Xfd))
        newobstimes[[j]] <- tfine
      }
            
              # if quantile transformation used, transform new predictors
      if(!is.null(fit$ecdflist) & type=='response'){
      
  	# need new curves to be observed at same time points as the original
  	# if(length(fit$ecdflist[[j]])!=
  
        if(N==1){ newXlist[[j]] <- mapply(function(ecdf,x){ecdf(x)},
                                     ecdf=fit$ecdflist[[j]],x=newXlist[[j]])
        }else{
          for(i in 1:N){
            newXlist[[j]][i,] <- mapply(function(ecdf,x){ecdf(x)},
                                     ecdf=fit$ecdflist[[j]],x=newXlist[[j]][i,])
          }
        }
      } # end if for handling quantile transformed data
      Li <- diff(newobstimes[[j]])[1]
      # N=1 case gives weird behaviour, so use UGLY hack: predict extra fake value
      L <- matrix(Li, nr=ifelse(N==1,2,N), nc=nt, byrow=TRUE)
      tmat <- matrix(newobstimes[[j]], nr=ifelse(N==1,2,N), nc=nt, byrow=TRUE)
      tempX <- newXlist[[j]]
      if(N==1){
        tempX <- rbind(tempX,rep(mean(tempX),nt))
      }
      newdata[[3*(j-1)+1]] <- tempX
      newdata[[3*(j-1)+2]] <- tmat
      newdata[[3*(j-1)+3]] <- L
      names(newdata)[3*(j-1)+1] <- paste('X',j,sep='')
      names(newdata)[3*(j-1)+2] <- paste('tmat',j,sep='')
      names(newdata)[3*(j-1)+3] <- paste('L',j,sep='')
    } # end loop over numfp  
    
    # include new values of linear, scalar covariates, if any
    if(!is.null(newlsp)){
      if(N==1){
        newdata$linscalpreds <- matrix(newlsp,nr=2,nc=length(newlsp),byrow=TRUE)
      }else{
        newdata$linscalpreds <- newlsp
      }
    }
    # include new values of nonparametric, scalar covariates, if any
    if(!is.null(newnpsplist)){
      numnpsp <- length(newnpsplist)
      for(j in 1:numnpsp){
        if(N==1){ # each item in list should be a single scalar
          newdata[[paste('z',j,sep='')]] <- matrix(newnpsplist[[1]],nr=2,nc=1)
        }else{
          newdata[[paste('z',j,sep='')]] <- newnpsplist[[1]]
        }
      }
    }
    
    #browser()
    preds <- predict(fit,newdata=newdata,type=type,outer.ok=TRUE)
    if(N==1)preds <- preds[1]
     return(m*preds)
  }
}

vis.fgam=function(fit,term=1,theta=50,plot.type='persp',ticktype='detailed',...){
  temp <- list()
  temp[[paste('L',term,sep='')]] <- 1
  if(plot.type=='persp'){
  vis.gam(fit,view=c(paste('X',term,sep=''),paste('tmat',term,sep='')),cond=temp,
          ticktype=ticktype,theta=theta,contour.col=rev(heat.colors(100)),...)#,xlab=bquote(paste(x[.(term)]))
  }else if(plot.type=='contour'){
    # not making use of vis.gam because want colour key/legend
    nfine <- 101
    tvals <- seq(0,1,l=nfine)
    xvals <- seq(fit$ranges[[2*term]][1],fit$ranges[[2*term]][2],l=nfine)
    temp <- expand.grid(tvals,xvals)
    newot <- temp[[1]]
    newX <- temp[[2]]
    preds <- predict.fgam(fit,newlsp=NULL,newnpsplist=NULL,newXlist=list(newX),
                        newobstimes=list(newot),type='surface',term=term)
    #trellis.par.set(regions=list(col=heat.colors))
    xlab=ifelse(is.null(fit$ecdflist),'x','p')
    levelplot(preds~newX*newot,contour=TRUE,labels=TRUE,pretty=TRUE,ylab='t',xlab=xlab,
              col.regions=rev(heat.colors(100)))
    
    #vis.gam(fit,view=c(paste('X',term,sep=''),paste('tmat',term,sep='')),cond=temp,
    #         plot.type=plot.type,...)
  }
}

slicesPlot <- function(fit,nfine=200,xfixedval,tfixedval,unifscaling=FALSE){
  x.mesh <- seq(fit$ranges$X1[1],fit$ranges$X1[2],length=nfine) ## where to evaluate derivatives
  t.mesh <- seq(fit$ranges$tmat1[1],fit$ranges$tmat1[2],length=nfine)

  if(missing(xfixedval)){
    xfixedval=sample(nfine,1)
  }else{
    if(xfixedval>fit$ranges$X1[2] | xfixedval<fit$ranges$X1[1]){
      stop(paste('Fixed x value must be in (',fit$ranges$X1[1],',',fit$ranges$X1[2],')',sep=''))
    }
    # from adaptive from function nearest in GenKern package
    upp <- which(x.mesh >= xfixedval)[1]
    low <- which(x.mesh <= xfixedval)
    low <- low[length(low)]
    upp <- x.mesh[upp]
    low <- x.mesh[low]
    if (upp == low) {
        index <- which(x.mesh == upp)
    }
    if ((abs(upp - xfixedval)) >= (abs(low - xfixedval))) {
        index <- which(x.mesh == low)
    }
    if ((abs(upp - xfixedval)) < (abs(low - xfixedval))) {
        index <- which(x.mesh == upp)
    }
    xfixedval <- index
  }
    
  if(missing(tfixedval)){
    tfixedval <- sample(nfine,1)
  }else{
    if(tfixedval>fit$ranges$tmat1[2] | tfixedval<fit$ranges$tmat1[1]){
      stop(paste('Fixed t value must be in (',fit$ranges$tmat1[1],',',fit$ranges$tmat1[2],')',sep=''))
    }
    upp <- which(t.mesh >= tfixedval)[1]
    low <- which(t.mesh <= tfixedval)
    low <- low[length(low)]
    upp <- t.mesh[upp]
    low <- t.mesh[low]
    if (upp == low) {
        index <- which(t.mesh == upp)
    }
    if ((abs(upp - tfixedval)) >= (abs(low - tfixedval))) {
        index <- which(t.mesh == low)
    }
    if ((abs(upp - tfixedval)) < (abs(low - tfixedval))) {
        index <- which(t.mesh == upp)
    }
    tfixedval <- index
  }  
  # F for fixed x first
  
  newd <- data.frame(X1 = rep(x.mesh[xfixedval],nfine),tmat1 = t.mesh, L1=rep(1,nfine))
  lpmat <- predict(fit,newd,type="lpmatrix")[,-1]
  Fxfixed <- lpmat%*%coef(fit)[-1] # don't include intercept
  Fxfixedsd <- rowSums(lpmat%*%fit$Vp[-1,-1]*lpmat)^.5
    
  # F for fixed t
  
  newd <- data.frame(X1 = x.mesh,tmat1 = rep(t.mesh[tfixedval],nfine), L1=rep(1,nfine))
  lpmat <- predict(fit,newd,type="lpmatrix")[,-1]
  Ftfixed <- lpmat%*%coef(fit)[-1]
  Ftfixedsd <- rowSums(lpmat%*%fit$Vp[-1,-1]*lpmat)^.5
  
  # d^2F/dx^2 F for fixed t
  x.mesh <- seq(fit$ranges$X1[1],fit$ranges$X1[2],length=nfine)
  newd <- data.frame(X1 = x.mesh,tmat1 = rep(t.mesh[tfixedval],nfine), L1=rep(1,nfine))
  X0 <- predict(fit,newd,type="lpmatrix") 
  
  eps <- 1e-7 ## finite difference interval
  x.mesh <- x.mesh + eps ## shift the evaluation mesh
  newd <- data.frame(X1 = x.mesh,tmat1 = rep(t.mesh[tfixedval],nfine), L1=rep(1,nfine))
  X1 <- predict(fit,newd,type="lpmatrix")
  
  x.mesh <- x.mesh + eps ## shift the evaluation mesh
  newd <- data.frame(X1 = x.mesh,tmat1 = rep(t.mesh[tfixedval],nfine), L1=rep(1,nfine))
  X2 <- predict(fit,newd,type="lpmatrix")
  
  lpmat <- (X2-2*X1+X0)/eps^2 ## maps coefficients to (fd approx.) derivatives
  #colnames(lpmat)      ## can check which cols relate to which smooth
  
  # column of zeros in lpmat for intercept
  F2derivtfixed <- lpmat%*%coef(fit)
  F2derivtfixedsd <- rowSums(lpmat%*%fit$Vp*lpmat)^.5

  # d^2F/dx^2 F for fixed x
  x.mesh <- seq(fit$ranges$X1[1],fit$ranges$X1[2],length=nfine)
  x.mesh <- rep(x.mesh[xfixedval],nfine)
  newd <- data.frame(X1 = x.mesh,tmat1 = t.mesh, L1=rep(1,nfine))
  X0 <- predict(fit,newd,type="lpmatrix") 
  
  eps <- 1e-7 ## finite difference interval
  x.mesh <- x.mesh + eps ## shift the evaluation mesh
  newd <- data.frame(X1 = x.mesh,tmat1 = t.mesh, L1=rep(1,nfine))
  X1 <- predict(fit,newd,type="lpmatrix")
  
  x.mesh <- x.mesh + eps ## shift the evaluation mesh
  newd <- data.frame(X1 = x.mesh,tmat1 = t.mesh, L1=rep(1,nfine))
  X2 <- predict(fit,newd,type="lpmatrix")
  
  lpmat <- (X2-2*X1+X0)/eps^2 ## maps coefficients to (fd approx.) derivatives
  #colnames(lpmat)      ## can check which cols relate to which smooth
  
  F2derivxfixed <- lpmat%*%coef(fit)
  F2derivxfixedsd <- rowSums(lpmat%*%fit$Vp*lpmat)^.5
  
  #par(mfrow=c(1,4))
  par(pty='m')    
  x.mesh <- seq(fit$ranges$X1[1],fit$ranges$X1[2],length=nfine)
      
  if(unifscaling){
  Frangex <- Franget <- range(Fxfixed+2*Fxfixedsd,Fxfixed-2*Fxfixedsd,
                   Ftfixed+2*Ftfixedsd,Ftfixed-2*Ftfixedsd)
  }else{
    Frangex <- range(Fxfixed+2*Fxfixedsd,Fxfixed-2*Fxfixedsd)
    Franget <- range(Ftfixed+2*Ftfixedsd,Ftfixed-2*Ftfixedsd)
  }
  # F for fixed t
  
  plot(x.mesh,Ftfixed,ylim=Franget,type='l',
       main=bquote(paste('a) ',hat('F')(x,.(round(t.mesh[tfixedval],3))),' by x',sep='')),
       xlab='',ylab='')
  lines(x.mesh,Ftfixed+2*Ftfixedsd,col=2,lty=2)
  lines(x.mesh,Ftfixed-2*Ftfixedsd,col=2,lty=2)
  
  # F for fixed x
  plot(t.mesh,Fxfixed,ylim=Frangex,type='l',
       main=bquote(paste('b) ',hat('F')(.(round(x.mesh[xfixedval],3)),t),' by t',sep='')),
       xlab='',ylab='')
  lines(t.mesh,Fxfixed+2*Fxfixedsd,col=2,lty=2)
  lines(t.mesh,Fxfixed-2*Fxfixedsd,col=2,lty=2)
  
  # d^2F/dx^2 F for fixed t
  if(unifscaling){
  Fdrangex <- Fdranget <-  range(F2derivtfixed+2*F2derivtfixedsd,F2derivtfixed-2*F2derivtfixedsd,
                 F2derivxfixed+2*F2derivxfixedsd,F2derivxfixed-2*F2derivxfixedsd)
  }else{
    Fdranget <-  range(F2derivtfixed+2*F2derivtfixedsd,F2derivtfixed-2*F2derivtfixedsd)
    Fdrangex <-  range(F2derivxfixed+2*F2derivxfixedsd,F2derivxfixed-2*F2derivxfixedsd)
  }
  plot(x.mesh,F2derivtfixed,ylim=Fdranget,type='l',
       main=bquote(paste('c) ',frac(partialdiff^2,partialdiff*x^2)*hat('F')(x,.(round(t.mesh[tfixedval],3))),' by x',sep='')),
       xlab='',ylab='')
  lines(x.mesh,F2derivtfixed+2*F2derivtfixedsd,col=2,lty=2)
  lines(x.mesh,F2derivtfixed-2*F2derivtfixedsd,col=2,lty=2)
  abline(h=0)
  
  # d^2F/dx^2 F for fixed x
  plot(t.mesh,F2derivxfixed,ylim=Fdrangex,type='l',
     main=bquote(paste('d) ',frac(partialdiff^2,partialdiff*x^2)*hat('F')(x,t),
      '|',phantom()[x==.(round(x.mesh[xfixedval],3))],' by t',sep='')),  
    xlab='',ylab='')
  lines(t.mesh,F2derivxfixed+2*F2derivxfixedsd,col=2,lty=2)
  lines(t.mesh,F2derivxfixed-2*F2derivxfixedsd,col=2,lty=2)
  abline(h=0)
}