source('CIsimFunctions.R')

nsim=1000
gsize=25
n=100
J=500
trueF='linear'
nfine=200
tfine=seq(0,1,l=nfine)
tmat=matrix(tfine,67,nfine,byrow=TRUE)
L=matrix(1/nfine,67,nfine)
nxbf=6
ntbf=7
snrs=c(1,2,4,8)
nsnr=length(snrs)
rmses=matrix(nr=nsim,nc=nsnr)
for(i in 1:nsim){

data=CreateData(n=n,gsize=gsize,fit='mgcv',trueF=trueF,adjustF='none',J=J,
	SNRs=snrs,lm=FALSE,sp=NULL,seed=NULL,sp0=c(1e-10,1e-10),varType='Bayes',
	xTrim=.00)
Ey=data$Ey
trainX=data$X[1:67,]
testX=data$X[68:100,]
sigmas=data$sigmae
rm(data)
for(j in 1:nsnr){
	trainy=Ey[1:67]+sigmas[j]*rnorm(67)
	testy=Ey[68:100]+sigmas[j]*rnorm(33)
	trainXq=apply(trainX, 2, function(x){
  				(rank(x)-1)/(length(x)-1)} )
          # need to keep ecdf's for prediction later
      Xecdf=apply(trainX, 2, ecdf) #list of length nfine ecdf's
	
	fgam1 <- gam(trainy~0+te(trainXq,tmat,by=L,k=c(nxbf,ntbf),bs='ps',
			m=c(2,2)),sp=NULL)
	#    trace(splines::spline.des, at=2, quote({
       #                 outer.ok <- TRUE
       #             }),print=FALSE)
     #on.exit(untrace(splines::spline.des))
	testXq=matrix(nr=33,nc=nfine)
	for(k in 1:33)
      	testXq[k,] <- mapply(function(ecdf,x){ecdf(x)},ecdf=Xecdf,x=testX[k,])
	newdata=list(trainXq=testXq,tmat=matrix(tfine,nr=33,nc=nfine,byrow=TRUE),
				L=matrix(1/nfine,33,nfine))
	yhat=predict(fgam1,newdata,'response')
	rmses[i,j]=sqrt(mean( (yhat-testy)^2 ))
}
print(paste(100*i/nsim,'% complete',sep=''))
flush.console()
}
fname=paste('rmseFGAMQJ',J,trueF,'.RData',sep='')
save(rmses,file=fname)