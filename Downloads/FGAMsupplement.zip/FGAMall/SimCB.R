# simulation experiment to examine coverage of Bayesian C.I.'s for FGAM
# see Section 4.2
# only points inside the convex hull formed by the observed (X(t),t) pairs are used to evaluate bands

source('CIsimFunctions.R')

nsim=500
gsize=25
n=100
in951=matrix(NA,nsim,gsize*gsize)
Fs1=array(0,dim=c(nsim,gsize,gsize))
stds1=Fs1
edfs1=numeric(nsim)
sigmas1=numeric(nsim)
biases1=matrix(0,nr=nsim,nc=n)
xgrids1=matrix(nr=nsim,nc=gsize)
in952=matrix(NA,nsim,gsize*gsize)
Fs2=array(0,dim=c(nsim,gsize,gsize))
stds2=Fs1
edfs2=numeric(nsim)
sigmas2=numeric(nsim)
biases2=matrix(0,nr=nsim,nc=n)
xgrids2=matrix(nr=nsim,nc=gsize)
for(i in 1:nsim){

data=CreateData(n=n,gsize=gsize,fit='mgcv',trueF='linear',adjustF='fit',SNRs=c(4),lm=FALSE,sp=NULL,
	seed=NULL,sp0=c(1e-10,1e-10),varType='Bayes',xTrim=.00)
# check all grid points for evaluating c.bands are inside polygon
# defined by observed data
tfine=seq(0,1,l=200)
Xrng <- cbind(rep(tfine, e=data$n), as.vector(data$X))[chull(cbind(rep(tfine, e=data$n),
		 as.vector(data$X))),]
inside <- insidePoly(cbind(rep(data$tgrid, data$gsize), 
		rep(data$xgrid, e=data$gsize)), Xrng)
test=RunSim(data,nsim=1,dir=getwd(),save=FALSE,clevel=.95)
in951[i,inside]=as.vector(test$in95)[inside]
Fs1[i,,]=test$Fs
stds1[i,,]=test$stds
edfs1[i]=test$edfs
sigmas1[i]=test$sigmas
biases1[i,]=test$biases
xgrids1[i,]=test$xgrid
data=CreateData(n=n,gsize=gsize,fit='mgcv',trueF='hill',adjustF='fit',SNRs=c(4),lm=FALSE,sp=NULL,
	seed=NULL,sp0=c(5e-8,5e-8),varType='Bayes',xTrim=.00,sx=10,st=.4)
# check all grid points for evaluating c.bands are inside polygon
# defined by observed data
tfine=seq(0,1,l=200)
Xrng <- cbind(rep(tfine, e=data$n), as.vector(data$X))[chull(cbind(rep(tfine, e=data$n),
		 as.vector(data$X))),]
inside <- insidePoly(cbind(rep(data$tgrid, data$gsize), 
		rep(data$xgrid, e=data$gsize)), Xrng)
test=RunSim(data,nsim=1,dir=getwd(),save=FALSE,clevel=.95)
in952[i,inside]=as.vector(test$in95)[inside]
Fs2[i,,]=drop(test$Fs)
stds2[i,,]=test$stds
edfs2[i]=test$edfs
sigmas2[i]=test$sigmas
biases2[i,]=test$biases
xgrids2[i,]=test$xgrid
}
save(in951,Fs1,stds1,edfs1,sigmas1,biases1,xgrids1,
	file='res1.RData')
save(in952,Fs2,stds2,edfs2,sigmas2,biases2,xgrids2,
	file='res2.RData')
